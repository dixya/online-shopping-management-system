<div class="sidebar">
<h3><a href="index.php">Main Navigation</a></h3>
<ul>
	<li><a href="managepassword.php">Change Password</a></li>
    	<li><a href="../shopuser/signupuser.php">Register new Shop</a></li>
    	<li><a href="manageshop.php">manage shop</a></li>
	<li><a href="managepages.php">Manage Pages</a></li>
	<li><a href="managecategory.php">Manage Category</a></li>
	<li><a href="manageproduct.php?id=0">Manage Product</a></li>
	<li><a href="manageinquiry.php">Manage Inquiry</a></li>
	<li><a href="logout.php">Logout</a></li>
	
</ul>
</div>